"use client";

import { useState, useEffect } from "react";
import { FaChevronLeft, FaChevronRight, FaCalendarAlt } from "react-icons/fa";
import "./AvailabilityCalendar.css";

// Helper to format any date input (string, Date object, ISO string) to "YYYY-MM-DD" consistently
function formatDateKey(rawDate) {
  if (!rawDate) return "";
  const str = String(rawDate).trim();
  // Extract YYYY-MM-DD directly if string starts with it (e.g. "2026-09-20T..." or "2026-09-20")
  const match = str.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (match) {
    return `${match[1]}-${match[2]}-${match[3]}`;
  }
  const d = new Date(rawDate);
  if (isNaN(d.getTime())) return "";
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, "0");
  const day = String(d.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export default function AvailabilityCalendar({ productId, bookedDates = [] }) {
  const now = new Date();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [apiBookedDates, setApiBookedDates] = useState([]);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  // Fetch live active bookings (pending/paid) for current month from API if productId is provided
  useEffect(() => {
    if (!productId) return;

    const fetchActiveBookings = async () => {
      try {
        const monthParam = `${year}-${String(month + 1).padStart(2, "0")}`;
        const res = await fetch(`/api/Bookings?month=${monthParam}`);
        if (res.ok) {
          const data = await res.json();
          const prodBooked = data.bookedDates?.[productId] || [];
          setApiBookedDates(prodBooked);
        }
      } catch (err) {
        console.error("Failed to fetch active bookings:", err);
      }
    };

    fetchActiveBookings();
  }, [productId, year, month]);

  // Combine product.bookedDates AND live apiBookedDates
  const combinedDates = [
    ...(bookedDates || []),
    ...(apiBookedDates || []),
  ];

  // Normalize booked dates into YYYY-MM-DD set
  const bookedSet = new Set(
    combinedDates
      .map(formatDateKey)
      .filter(Boolean)
  );

  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  // Days calculation
  const firstDayOfMonth = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  // Disable navigating to past months (before today's month)
  const isPastMonthDisabled =
    year < now.getFullYear() ||
    (year === now.getFullYear() && month <= now.getMonth());

  const prevMonth = () => {
    if (isPastMonthDisabled) return;
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const days = [];
  // Blank days before first day of month
  for (let i = 0; i < firstDayOfMonth; i++) {
    days.push(null);
  }
  // Days of month
  for (let day = 1; day <= daysInMonth; day++) {
    const formattedMonth = String(month + 1).padStart(2, "0");
    const formattedDay = String(day).padStart(2, "0");
    const dateKey = `${year}-${formattedMonth}-${formattedDay}`;
    days.push({
      day,
      dateKey,
      isBooked: bookedSet.has(dateKey),
    });
  }

  // Today in local YYYY-MM-DD
  const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;

  return (
    <div className="availability-calendar-wrapper">
      <div className="calendar-header-bar">
        <button
          type="button"
          onClick={prevMonth}
          disabled={isPastMonthDisabled}
          className="cal-nav-btn"
          title={isPastMonthDisabled ? "Cannot view past months" : "Previous Month"}
        >
          <FaChevronLeft />
        </button>
        <div className="cal-title-wrap">
          <FaCalendarAlt className="cal-icon" />
          <span className="cal-title">
            {monthNames[month]} {year}
          </span>
        </div>
        <button type="button" onClick={nextMonth} className="cal-nav-btn" title="Next Month">
          <FaChevronRight />
        </button>
      </div>

      <div className="calendar-grid-box">
        {daysOfWeek.map((d) => (
          <div key={d} className="cal-day-header">
            {d}
          </div>
        ))}

        {days.map((item, index) => {
          if (!item) {
            return <div key={`empty-${index}`} className="cal-day empty" />;
          }

          const isPast = item.dateKey < todayStr;
          const isToday = item.dateKey === todayStr;
          // Only show RED if it's booked AND not in the past
          const isBookedActive = !isPast && item.isBooked;

          return (
            <div
              key={item.dateKey}
              className={`cal-day ${
                isPast
                  ? "past"
                  : isBookedActive
                  ? "booked"
                  : "available"
              } ${isToday ? "today" : ""}`}
              title={
                isPast
                  ? "Past Date / تاريخ سابق"
                  : isBookedActive
                  ? "Booked / متأجر"
                  : "Available / متاح"
              }
            >
              <span className="day-number">{item.day}</span>
              {isBookedActive && <span className="booked-badge">Rented</span>}
            </div>
          );
        })}
      </div>

      <div className="calendar-legend-bar">
        <div className="legend-item">
          <span className="legend-dot booked-dot" />
          <span>Booked / متأجر (أحمر)</span>
        </div>
        <div className="legend-item">
          <span className="legend-dot available-dot" />
          <span>Available / متاح</span>
        </div>
      </div>
    </div>
  );
}
